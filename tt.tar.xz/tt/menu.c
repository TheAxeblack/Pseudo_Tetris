#include<stdio.h>
#include<stdlib.h>
#include <MLV/MLV_all.h>

typedef enum{nvlprt, chargerprt, score, quitter} ChoixMenu;


int main(int argc, char *argv[]){
  
  MLV_Image *image;
  int a, b;
  a=260;b=280;
  MLV_create_window( "tetris", "menu", 640, 480 );

  image=MLV_load_image( "image/logo.jpg" );
  
 
  MLV_draw_filled_rectangle(0, 0, 640, 480, MLV_COLOR_BLACK);
  
  MLV_resize_image_with_proportions( image, 640, 480);
  
  MLV_draw_image( image, 0, 0 );
  
  MLV_draw_text_box(260,280,120,46,"START",10,MLV_COLOR_BLUE3,MLV_COLOR_WHITE,MLV_COLOR_BLACK,MLV_TEXT_CENTER,MLV_HORIZONTAL_CENTER,MLV_VERTICAL_CENTER);

  
  MLV_actualise_window();
  MLV_wait_mouse_or_seconds(NULL, NULL, 4);
  
  MLV_get_mouse_position(&a,&b);
  if( MLV_get_mouse_button_state( MLV_BUTTON_LEFT ) == MLV_PRESSED ){
    MLV_actualise_window();
     MLV_draw_filled_rectangle(0, 0, 640, 480, MLV_COLOR_BLACK);
    MLV_draw_text_box(260,30,120,46,"nouvelle partie",10,MLV_COLOR_BLUE3,MLV_COLOR_WHITE,MLV_COLOR_BLACK,MLV_TEXT_CENTER,MLV_HORIZONTAL_CENTER,MLV_VERTICAL_CENTER);
    MLV_draw_text_box(260,122,120,46,"charger la partie",10,MLV_COLOR_BLUE3,MLV_COLOR_WHITE,MLV_COLOR_BLACK,MLV_TEXT_CENTER,MLV_HORIZONTAL_CENTER,MLV_VERTICAL_CENTER);
    MLV_draw_text_box(260,216,120,46,"meilleur score",10,MLV_COLOR_BLUE3,MLV_COLOR_WHITE,MLV_COLOR_BLACK,MLV_TEXT_CENTER,MLV_HORIZONTAL_CENTER,MLV_VERTICAL_CENTER);
    MLV_draw_text_box(260,310,120,46,"regle du jeux",10,MLV_COLOR_BLUE3,MLV_COLOR_WHITE,MLV_COLOR_BLACK,MLV_TEXT_CENTER,MLV_HORIZONTAL_CENTER,MLV_VERTICAL_CENTER);
    MLV_draw_text_box(260,404,120,46,"quitter",10,MLV_COLOR_BLUE3,MLV_COLOR_WHITE,MLV_COLOR_BLACK,MLV_TEXT_CENTER,MLV_HORIZONTAL_CENTER,MLV_VERTICAL_CENTER);
  }
  MLV_actualise_window(); 
  
  
  MLV_wait_seconds( 10 );
        
  
        
  MLV_free_window();
  return 0;
}

